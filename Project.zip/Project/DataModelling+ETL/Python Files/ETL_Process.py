#!/usr/bin/env python
# coding: utf-8

# In[18]:


import pandas as pd
from datetime import datetime
# import the connect library for psycopg2
import psycopg2
#for connecting to Postgres
from sqlalchemy import create_engine


# In[19]:


def Create_Database_Connection():
    """Summary: Function to Create Database connection and a cursor
    
        Input: No Input
    
        Output: Returns new Connection object created and the cursor created
    
        Description: This function is used to connect to Postgres Database and create a cursor to execute the SQL"""
    #Logging into Postgres schema
    conn = psycopg2.connect(dbname="Grover_project", user="postgres", password="Avyukt*123",host="localhost")
    cursor = conn.cursor()
    return conn,cursor


# In[20]:


def Close_Database_Connection(conn):
    """Summary: Function to Close the Database connection
    
        Input: Connection object created to connect to Database connection
    
        Output: No Return Value
    
        Description: This function is used to commit the transactions to database and close the connection """
    conn.commit()
    #Closing the SQL Connection.
    conn.close()


# In[21]:


def read_table(table_name):
    """Summary: Function to Read the table contents from database
    
        Input: Table Name which needs to be read
    
        Output: Returns the dataframe where the contents of the table is stored
    
        Description: This function is used to read the data from the table. The query is to read only active records from the table """
    # Create an engine instance
    alchemyEngine   = create_engine('postgresql://postgres:Avyukt*123@localhost:5432/Grover_project')
    # Connect to PostgreSQL server
    dbConnection    = alchemyEngine.connect()
    table='public.'+'"'+table_name+'"'
    sql='Select * from {} where "Is_Active"=\'Y\';'.format(table)
    # Read data from PostgreSQL database table and load into a DataFrame instance
    dataFrame  = pd.read_sql(sql, dbConnection)
    
    return dataFrame


# In[22]:


def insert_row(table_name,tuple_row):
    """Summary: Function to insert single row to the table
    
        Input: Table name where data needs to be inserted 
               The row that needs to be inserted
    
        Output: No Return Value
    
        Description: This function is used to write a single row to the database  """
    #Create Connection
    conn,cursor=Create_Database_Connection()
    # dataframe columns with Comma-separated
    table='public.'+'"'+table_name+'"'
    # SQL query to execute
    tuple_row='(DEFAULT,'+str(tuple_row).strip("(")
    sql = "INSERT INTO {} VALUES{}" .format (table,tuple_row)
    cursor.execute(sql)
    
    
    #print('{} Inserted Successfully'.format(table_name))
    Close_Database_Connection(conn)   


# In[23]:


def insert_bulk(table_name,df):
    """Summary: Function to insert bulk data to the table
    
        Input: Table name where the data needs to be inserted 
               The dataframe that needs to be inserted
    
        Output: No Return Value
    
        Description: This function is used to bulk recrods to the database used for the first run of the database  """
    #Create Connection
    conn,cursor=Create_Database_Connection()
    # dataframe columns with Comma-separated
    table='public.'+'"'+table_name+'"'
    # SQL query to execute
    for i in tuple(df.to_records(index=False)):
        i='(DEFAULT,'+str(i).strip("(")
        sql = "INSERT INTO {} VALUES{}" .format (table,i)
        cursor.execute(sql)
    #print('{} Inserted Successfully'.format(table_name))
    Close_Database_Connection(conn)
    


# In[24]:


def update_row(table_name,Id,Col):
    """Summary: Function to update single row to the table
    
        Input: Table name where data needs to be updated
               Col the primary key of the table
               Id - The record which needs to be updated
    
        Output: No Return Value
    
        Description: This function is used to update single row to the database. This is used to mark the record as inactive in 
        database"""
    #Create Connection
    conn,cursor=Create_Database_Connection()
    col_name='"'+Col+'"'
    table='public.'+'"'+table_name+'"'
    sql = """ UPDATE {}
                SET 
                "Is_Active"='N'
                WHERE {} ={}""".format(table,col_name,Id)
    
    # SQL query to execute
    cursor.execute(sql)
    Close_Database_Connection(conn)


# In[25]:


def insert_update_load(table_name,df_source,id_target,id_check_source,id_check_target,col_check_source,col_check_target):
    """Summary: Function to perform ETL operation to the Dimension and the Fact table
    
        Input: Table name where the insert update operation needs to be performed
               Datframe which stores the data that needs to be loaded to table
               Id_Target_id- the Primary key column name of the table, The surrogate key column name generated in the database
               id_check_source- Unique identifier column name from the source file
               id_check_target- Source unique id name present in the warehouse used as lookup to check if 
                                the value exsits in the table already
               col_check_source- The column name in source file which is used to check if there is any update in the source
               col_check_target- The column name in target table which is used to check if there is any update in the source
    
        Output: No Return Value
    
        Description: This function is used to perform ETL insert update operation in warehouse.
                     The source file is passed as input and for each line in source file value is checked if it is already available in table.
                     
                     1. If the record is already available in the table then if there is any update in the data 
                     then the Is_Active flag for present record in the table will be marked as N and updated entry will be inserted as
                     new entry to the table.
                     
                     2. If the record is not available then the record will be inserted with Is_Active_Flag as Y
                     
                     3. If the record is available and no change in data in the column no action will be done on the record.
                     
                     The function prints the number of rows updated and inserted in the table.
                     """
    ins_cnt=0
    upd_cnt=0
    df_target=read_table(table_name)
    
    if not df_target.empty:
        for i,row in df_source.iterrows():
            df=pd.DataFrame(df_target[(df_target[id_check_target]==row[id_check_source]) & (df_target[col_check_target]!=row[col_check_source])])
            
            
            if df.empty and (row[id_check_source] not in list(df_target[id_check_target])):
                    
                    insert_row(table_name,tuple(row))
                    ins_cnt=ins_cnt+1
            elif not df.empty:
                df=df.reset_index()
                update_row(table_name,df.loc[0,id_target],id_target)
                upd_cnt=upd_cnt+1
                insert_row(table_name,tuple(row))
                ins_cnt=ins_cnt+1
    else:
        insert_bulk(table_name,df_source)
        ins_cnt=len(df_source)
    
    print('{} records are Inserted and {} records are Updated in {}'.format(ins_cnt,upd_cnt,table_name))
    


# In[26]:


def dimension_lookup(df_dim,row,src_col,lkp_col,rtn_col):
    """Summary: Function to perform Lookup operation to the Dimension to load the fact table for each row in fact load
    
        Input: Data from the Dimension from the table
               Fact data row for which the vlookup is performed
               src_col- The source unique column name available in the fact row that needs to be looked up in the table
               lkp_col- The source unique column name available in the dimension table that needs to be looked up in the table
               rtn_col- The surrogate key column name from the dimension table 
               
        Output: Returns the surrogate key value from the dimension table that will be the foriegn key in the fact table 
    
        Description: This function is used to perform vlookup on the dimesnion table and get the surrogate key for the source 
                     id for each fact row 
                     """
    df=pd.DataFrame(df_dim[df_dim[lkp_col]==row[src_col]])
    df=df.reset_index()
    return df.loc[0,rtn_col]


# In[27]:


#Load the source files to the dataframe
order=pd.read_csv("Order.csv")
category=pd.read_csv("category.csv")
country=pd.read_csv("country.csv")
order_status=pd.read_csv("order_status.csv")


# In[28]:


#Change the date format of the source file from DD.MM.YY to YYYYMMDD format
order['date_id']=order['creation_date'].apply(lambda x: datetime.strptime(x,'%d.%m.%y').strftime('%Y%m%d'))
#Generate new dataframe from the source file to match the target format
Category_new=pd.DataFrame({"Category_Code_Id":category['id'],"Category":category['category'],'Is_Active':'Y'})
Country_new=pd.DataFrame({"Country_Code_Id":country['id'],"Country":country['Country'],'Is_Active':'Y'})
Order_Status_new=pd.DataFrame({"Status_Code_Id":order_status['status_code'],"Status":order_status['status'],'Is_Active':'Y'})


# In[29]:


# Dimension Loads 
insert_update_load("Category_Dimension",Category_new,'Category_Id','Category_Code_Id','Category_Code_Id','Category','Category')
insert_update_load("Country_Dimension",Country_new,'Country_Id','Country_Code_Id','Country_Code_Id','Country','Country')
insert_update_load("Order_Status_Dimension",Order_Status_new,'Status_Id','Status_Code_Id','Status_Code_Id','Status','Status')


# In[30]:


#Get the dimension data from the warehouse
df_category_dim=read_table("Category_Dimension")
df_country_dim=read_table("Country_Dimension")
df_order_status_dim=read_table("Order_Status_Dimension")

#Generate dataframe for the fact file
df_order_fact=pd.DataFrame(columns = ['Order_Code_Id','order_date_id','Country_Code_Id','Status_Code_Id','Category_Code_Id','order_value','Is_Active'])
for i,row in order.iterrows():
    #for each dimesnion columns perform vlookup
    cntr_cod=dimension_lookup(df_country_dim,row,'country_id','Country_Code_Id','Country_Id')
    cat_code=dimension_lookup(df_category_dim,row,'category_id','Category_Code_Id','Category_Id')
    sts_code=dimension_lookup(df_order_status_dim,row,'status_id','Status_Code_Id','Status_Id')
    
    #Inser the data in the target format for the fact.
    df_order_fact = df_order_fact.append({"Order_Code_Id":row['order_id'],'order_date_id':row['date_id'],'Country_Code_Id':cntr_cod,'Status_Code_Id':sts_code,'Category_Code_Id':cat_code,'order_value':round(row['order_value'],4),'Is_Active':'Y'}, ignore_index=True)


# In[31]:


#Fact Load
insert_update_load("Order_Details_Fact",df_order_fact,'Order_Id','Order_Code_Id','Order_Code_Id','Status_Code_Id','Status_Code_Id')


# In[ ]:




