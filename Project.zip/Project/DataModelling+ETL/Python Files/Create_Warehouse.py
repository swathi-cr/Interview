#!/usr/bin/env python
# coding: utf-8

# In[38]:


#For loading the Country_Code file to Table
import pandas as pd 
#for connecting to Postgres
from sqlalchemy import create_engine 
print('Libraries Imported')


# In[39]:


def Create_Date_Dimension(start='01-01-2019', end='31-12-2021'):
    """ 
        Summary: Function to Create Date Dimension dataframe
    
        Input: Start and End dates for which the dimension will be loaded
    
        Output: Date Dimension Dataframe
    
        Description: This function will take the Start and End date and generate value to be loaded to Date Dimension
    """
    date_df = pd.DataFrame({"date": pd.date_range(start, end)})
    date_df["day"] = date_df.date.apply(lambda x:x.strftime("%d"))
    date_df["month"] = date_df.date.apply(lambda x:x.strftime("%m"))
    date_df["weekofyear"] = date_df.date.dt.isocalendar().week
    date_df["quarter"] = date_df.date.dt.quarter
    date_df["year"] = date_df.date.dt.year
    date_df["month_name"]=date_df.date.dt.month_name()
    date_df['weekday_number']=date_df.date.dt.dayofweek
    date_df['weekday_name']=date_df.date.apply(lambda x:x.strftime("%A"))
    date_df.insert(0, 'date_id', (date_df.year.astype(str) + date_df.month.astype(str) + date_df.day.astype(str)).astype(int))
    
    return date_df


# In[40]:


#Logging into Postgres schema:Grover_Project
engine = create_engine('postgresql://postgres:Avyukt*123@localhost:5432/Grover_project')
print('Postgres DataBase Engine Created')
#Creating Raw connection
conn = engine.raw_connection()
print('Connection to Engine Created')

#Create a cursor connection
cur = conn.cursor()
print('Cursor to the Database Created')


# In[41]:


#Dropping Materialized View if exsits
drop_mv1_query="""DROP MATERIALIZED VIEW IF EXISTS public.monthly_order_value_status_agg;"""
drop_mv2_query="""DROP MATERIALIZED VIEW IF EXISTS public.monthly_order_value_country_agg;"""
drop_mv3_query="""DROP MATERIALIZED VIEW IF EXISTS public.monthly_order_value_category_agg;"""
drop_mv4_query="""DROP MATERIALIZED VIEW IF EXISTS public.monthly_order_value_agg;"""
cur.execute(drop_mv1_query)
print('Deleting the materialized view monthly_order_value_status_agg if Exists')
cur.execute(drop_mv2_query)
print('Deleting the materialized view monthly_order_value_country_agg if Exists')
cur.execute(drop_mv3_query)
print('Deleting the materialized view monthly_order_value_category_agg if Exists')
cur.execute(drop_mv4_query)
print('Deleting the materialized view monthly_order_value_agg if Exists')


# In[42]:


#Dropping the table if exsists
drop_table1_query="""DROP TABLE IF EXISTS public."Order_Details_Fact";"""
drop_table2_query="""DROP TABLE IF EXISTS public."Category_Dimension";""" 
drop_table3_query="""DROP TABLE IF EXISTS public."Country_Dimension";"""
drop_table4_query="""DROP TABLE IF EXISTS public."Date_Dimension";"""
drop_table5_query="""DROP TABLE IF EXISTS public."Order_Status_Dimension";"""
cur.execute(drop_table1_query)
print('Deleting the table Order_Details_Fact if Exists')
cur.execute(drop_table2_query)
print('Deleting the table Category_Dimension if Exists')
cur.execute(drop_table3_query)
print('Deleting the table Country_Dimension if Exists')
cur.execute(drop_table4_query)
print('Deleting the table Date_Dimension if Exists')
cur.execute(drop_table5_query)
print('Deleting the table Order_Status_Dimension if Exists')


# In[43]:


#Creating Dimension for storing the Category Dimension
table_creation1_query="""CREATE TABLE public."Category_Dimension"
(
    "Category_Id" SERIAL NOT NULL ,
    "Category_Code_Id" integer NOT NULL,
    "Category" varchar(250),
    "Is_Active" character varying(10),
    PRIMARY KEY ("Category_Id")
);"""
cur.execute(table_creation1_query)
print('Category_Dimension Table created in the Database')


# In[44]:


#Creating Dimension for storing the Country Dimension
table_creation2_query="""CREATE TABLE public."Country_Dimension"
(
    "Country_Id" SERIAL NOT NULL ,
    "Country_Code_Id" integer NOT NULL,
    "Country" varchar(250),
    "Is_Active" character varying(10),
    PRIMARY KEY ("Country_Id")
);"""
cur.execute(table_creation2_query)
print('Country_Dimension Table created in the Database')


# In[45]:


#Creating Dimension for storing the Order_Status Dimension
table_creation4_query="""CREATE TABLE public."Order_Status_Dimension"
(
    "Status_Id" SERIAL NOT NULL ,
    "Status_Code_Id" integer NOT NULL,
    "Status" varchar(250),
    "Is_Active" character varying(10),
    PRIMARY KEY ("Status_Id")
);"""
cur.execute(table_creation4_query)
print('Order_Status_Dimension Table created in the Database')


# In[46]:


#Creating Dimension for storing the Dates Dimension
table_creation3_query="""CREATE TABLE public."Date_Dimension"
(
    "Date_Id" integer NOT NULL,
    "Date" date,
    "Day" integer,
    "Month" integer,
    "Weekofyear" integer,
    "Quarter" integer,
    "Year" integer,
    "Month_Name" varchar(250) COLLATE pg_catalog."default",
    "Weekday_Number" integer,
    "Weekday_Name" varchar(250) COLLATE pg_catalog."default",
    CONSTRAINT "Date_Dimension_pkey" PRIMARY KEY ("Date_Id")
);"""
cur.execute(table_creation3_query)
print('Date_Dimension Table created in the Database')


# In[47]:


#Creating Dimension for storing the Order_Details Fact
table_creation5_query="""CREATE TABLE public."Order_Details_Fact"
(
    "Order_Id" SERIAL NOT NULL ,
    "Order_Code_Id" character varying(1000) COLLATE pg_catalog."default",
    "Order_Date_Id" integer,
    "Country_Code_Id" integer,
    "Status_Code_Id" integer,
    "Category_Code_Id" integer,
    "Order_Value" numeric(25,4),
    "Is_Active" character varying(10) COLLATE pg_catalog."default",
    CONSTRAINT "Order_Details_Fact_pkey" PRIMARY KEY ("Order_Id"),
    CONSTRAINT "Category_Code_Id_FK" FOREIGN KEY ("Category_Code_Id")
        REFERENCES public."Category_Dimension" ("Category_Id") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "Country_Code_Id_FK" FOREIGN KEY ("Country_Code_Id")
        REFERENCES public."Country_Dimension" ("Country_Id") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT "Order_Date_Id_FK" FOREIGN KEY ("Order_Date_Id")
        REFERENCES public."Date_Dimension" ("Date_Id") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT "Status_Code_Id_FK" FOREIGN KEY ("Status_Code_Id")
        REFERENCES public."Order_Status_Dimension" ("Status_Id") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
"""
cur.execute(table_creation5_query)
print('Order_Details_Fact Table created in the Database')


# conn.commit()

# In[48]:


#Load the Date Dimension from Dataframe
date_dataframe=Create_Date_Dimension()
table='public.'+'"'+'Date_Dimension'+'"'
    # SQL query to execute
for i in tuple(date_dataframe.to_records(index=False)):
    sql = "INSERT INTO {} VALUES{}" .format (table,i)
    cur.execute(sql)
conn.commit()
print('Date_Dimension Loaded to Database')


# In[49]:


#Creation of Materialized view
mv1_create_query="""CREATE MATERIALIZED VIEW Monthly_Order_Value_Agg AS
SELECT d."Year",d."Month_Name",sum(f."Order_Value") Total_Month_Order_Value,count(f."Order_Value") Total_Month_Order_Count FROM public."Order_Details_Fact" f
inner join public."Date_Dimension" d on d."Date_Id"=f."Order_Date_Id" and f."Is_Active"='Y'
group by d."Year",d."Month_Name";"""
cur.execute(mv1_create_query)
print('Monthly_Order_Value_Agg View created in the Database')


# In[50]:


#Creation of Materialized view
mv2_create_query="""create MATERIALIZED VIEW Monthly_Order_Value_Category_Agg AS
SELECT dc."Category",d."Year",d."Month_Name",d."Month",sum(f."Order_Value") Total_Month_Order_Value,count(f."Order_Value") Total_Month_Order_Count FROM public."Order_Details_Fact" f
inner join public."Category_Dimension" dc on dc."Category_Id"=f."Category_Code_Id" and dc."Is_Active"='Y'
inner join public."Date_Dimension" d on d."Date_Id"=f."Order_Date_Id" 
where f."Is_Active"='Y'
group by d."Year",d."Month_Name", dc."Category",d."Month" order by d."Month" ;"""
cur.execute(mv2_create_query)
print('Monthly_Order_Value_Category_Agg View created in the Database')


# In[51]:


#Creation of Materialized view
mv3_create_query="""create MATERIALIZED VIEW Monthly_Order_Value_Country_Agg AS
SELECT dc."Country",d."Year",d."Month_Name",d."Month",sum(f."Order_Value") Total_Month_Order_Value,count(f."Order_Value") Total_Month_Order_Count FROM public."Order_Details_Fact" f
inner join public."Country_Dimension" dc on dc."Country_Id"=f."Country_Code_Id" and dc."Is_Active"='Y'
inner join public."Date_Dimension" d on d."Date_Id"=f."Order_Date_Id" 
where f."Is_Active"='Y'
group by d."Year",d."Month_Name", dc."Country",d."Month" order by d."Month" ;"""
cur.execute(mv3_create_query)
print('Monthly_Order_Value_Country_Agg View created in the Database')


# In[52]:


#Creation of Materialized view
mv4_create_query="""create MATERIALIZED VIEW Monthly_Order_Value_Status_Agg AS
SELECT dos."Status",d."Year",d."Month_Name",d."Month",sum(f."Order_Value") Total_Month_Order_Value,count(f."Order_Value") Total_Month_Order_Count FROM public."Order_Details_Fact" f
inner join public."Order_Status_Dimension" dos on dos."Status_Id"=f."Status_Code_Id" and dos."Is_Active"='Y'
inner join public."Date_Dimension" d on d."Date_Id"=f."Order_Date_Id" 
where f."Is_Active"='Y'
group by d."Year",d."Month_Name", dos."Status",d."Month" order by d."Month" ;"""
cur.execute(mv4_create_query)
print('Monthly_Order_Value_Status_Agg View created in the Database')


# In[53]:


#Closing the SQL Connection.
conn.commit()
print('Closing the SQL Connection')
conn.close()


# In[ ]:




