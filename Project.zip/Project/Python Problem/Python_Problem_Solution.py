#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#for Sleep
import time 


# In[8]:


#Generate pattern for rows till the row value from the input value and check the length if the length
def Function_X(val):
    """Summary: Function to get the Number of rows the input value can fill
    
        Input: Value which has been passed as input by user 
    
        Output: Returns the number of rows that can be filled completely
    
        Description: This function is used to get the maximum row the input value can fill in the triangle.
                     The pattern will be generated similar to balls inside the triangle.
                     The pattern for each row will be generated and length of the pattern is checked against input value
                     When the length of the pattern is greater than or equal to the input value.
                     Then if length is equal to the input value then input value will fill rows completly.
                     If the length is greater than input value then input value will not fill rows completly so the previous row will be returned"""
    s=0
    for i in range(1,val):
        s=len("O"*i)+s
        if s>=val:
            if s==val:
                r1=i
            else:
                r1=i-1
            break
    return r1


# In[7]:


#Get the input value
input_val = input("Enter the value and press enter: ")
#Convert input from string to int
val=int(input_val)


# In[9]:


print('Number of rows filled by {} balls are {}'.format(val,Function_X(val)))
#Putting application for sleep 30 secs to see results
time.sleep(30)


# In[ ]:




